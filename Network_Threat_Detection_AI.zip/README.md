# Predictive Modelling for Network Threat Detection Using Artificial Intelligence

This project focuses on detecting and predicting network threats using AI-based techniques. It consists of six modules, each addressing a key aspect of the pipeline.

## 📁 Project Structure

```
Network_Threat_Detection_AI/
├── module1_data_preprocessing/
├── module2_data_visualization/
├── module3_bayesian_classifier/
├── module4_adaboost_classifier/
├── module5_random_forest/
├── module6_report/
├── requirements.txt
└── README.md
```

## 🧩 Modules Description

1. **Module 1 - Data Preprocessing**: Cleans and formats the dataset for use.
2. **Module 2 - Data Visualization**: Explores the dataset with visual graphs.
3. **Module 3 - Bernoulli Naive Bayes Classifier**: Implements BNB for threat detection.
4. **Module 4 - AdaBoost Classifier**: Applies AdaBoost for classification.
5. **Module 5 - Random Forest Classifier**: Uses Random Forest for modeling threats.
6. **Module 6 - Final Report**: Summarizes findings and results.

## 📦 Installation

```bash
pip install -r requirements.txt
```

## 🚀 Usage

Open each Jupyter Notebook in the respective module folder to run the project.

